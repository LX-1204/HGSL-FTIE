import os
import psutil
from data import *
from module.dblp.model import HGSL_FTIE
from pytorchtools import EarlyStopping
from tools import *
import argparse
import random
import time
from sklearn.manifold import TSNE
import matplotlib.pyplot as plt
import warnings

warnings.filterwarnings("ignore")
def set_random_seed(seed=0):
    random.seed(seed)
    np.random.seed(seed)
    torch.manual_seed(seed)
    if torch.cuda.is_available():
        torch.cuda.manual_seed(seed)


def main(args):
    features_G, feat, ADJ_t, labels, num_classes, train_idx, val_idx, test_idx =load_DBLP_data()
    in_dims = [feature.shape[1] for feature in features_G]
    features_G = [feature.to(args['device']) for feature in features_G]
    labels = labels.to(args['device'])

    for i in range(len(ADJ_t)):
        ADJ_t[i] = ADJ_t[i].to(args['device'])
    for j in range(len(feat)):
        feat[j] = feat[j].to(args['device'])

    svm_macro_avg = np.zeros((7,), dtype=np.float)
    svm_micro_avg = np.zeros((7,), dtype=np.float)
    nmi_avg = 0
    ari_avg = 0
    print('start train with repeat = {}\n'.format(args['repeat']))
    for cur_repeat in range(args['repeat']):
        print('cur_repeat = {}   ==============================================================='.format(cur_repeat))
        model = HGSL_FTIE(args['hidden_units'],args,args['lam'],args['alpha'],in_dims, args['feat_drop'], args['att_drop'] ,len(ADJ_t), num_classes, args['dropout']).to(args['device'])
        early_stopping = EarlyStopping(patience=args['patience'], verbose=True, save_path='checkpoint/checkpoint_{}.pt'.format(args['dataset']))
        loss_fcn = torch.nn.CrossEntropyLoss()
        optimizer = torch.optim.Adam(model.parameters(), lr=args['lr'], weight_decay=args['weight_decay'])
        drop_rate = [0,0]
        for epoch in range(args['num_epochs']):
            model.train()
            logits, h = model(features_G,feat,ADJ_t)
            loss = loss_fcn(logits[train_idx], labels[train_idx])
            optimizer.zero_grad()
            loss.backward()
            optimizer.step()
            model.eval()
            logits, h = model(features_G,feat,ADJ_t)
            val_loss = loss_fcn(logits[val_idx], labels[val_idx])
            test_loss = loss_fcn(logits[test_idx], labels[test_idx])
            print('Epoch{:d}| Train Loss{:.4f}| Val Loss{:.4f}| Test Loss{:.4f}'.format(epoch + 1, loss.item(), val_loss.item(), test_loss.item()))
            early_stopping(val_loss.data.item(), model)
            if early_stopping.early_stop:
                print('Early stopping!')
                break
        print('\ntesting...')
        model.load_state_dict(torch.load('checkpoint/checkpoint_{}.pt'.format(args['dataset'])))
        model.eval()
        logits, h = model(features_G,feat,ADJ_t)
        svm_macro, svm_micro, nmi, ari = evaluate_results_nc(h[test_idx].detach().cpu().numpy(), labels[test_idx].cpu().numpy(), int(labels.max()) + 1)
        svm_macro_avg = svm_macro_avg + svm_macro
        svm_micro_avg = svm_micro_avg + svm_micro
        nmi_avg += nmi
        ari_avg += ari
        Y = labels[test_idx].cpu().numpy()
        ml = TSNE(n_components=2)
        node_pos = ml.fit_transform(h[test_idx].cpu().data.numpy())
        color_idx = {}
        for i in range(len(h[test_idx].cpu().data.numpy())):
            color_idx.setdefault(Y[i], [])
            color_idx[Y[i]].append(i)
        for c, idx in color_idx.items():
            if str(c) == '1':
                plt.scatter(node_pos[idx, 0], node_pos[idx, 1], c='#006400', s=15, alpha=1)
            elif str(c) == '2':
                plt.scatter(node_pos[idx, 0], node_pos[idx, 1], c='#8B0000', s=15, alpha=1)
            elif str(c) == '0':
                plt.scatter(node_pos[idx, 0], node_pos[idx, 1], c='#6A5ACD', s=15, alpha=1)
            elif str(c) == '3':
                plt.scatter(node_pos[idx, 0], node_pos[idx, 1], c='#DAA520', s=15, alpha=1)
        plt.legend()
        plt.savefig("DBLP Visualization" + ".png", dpi=1000, bbox_inches='tight')
        plt.show()

    svm_macro_avg = svm_macro_avg / args['repeat']
    svm_micro_avg = svm_micro_avg / args['repeat']
    nmi_avg /= args['repeat']
    ari_avg /= args['repeat']
    print('---\nThe average of {} results:'.format(args['repeat']))
    print('Macro-F1: ' + ', '.join(['{:.6f}'.format(macro_f1) for macro_f1 in svm_macro_avg]))
    print('Micro-F1: ' + ', '.join(['{:.6f}'.format(micro_f1) for micro_f1 in svm_micro_avg]))
    print('NMI: {:.6f}'.format(nmi_avg))
    print('ARI: {:.6f}'.format(ari_avg))
    print('all finished')


if __name__ == '__main__':
    parser = argparse.ArgumentParser(description='our models')
    parser.add_argument('--dataset', default='DBLP', help='dataset')
    parser.add_argument('--lr', default=0.0003, help='learning rate')
    parser.add_argument('--weight_decay', default=0.0000, help='weight decay')
    parser.add_argument('--hidden_units', default=64, help='hidden units')
    parser.add_argument('--feat_drop', default=0.4, help='feature dropout rate')
    parser.add_argument('--att_drop', default=0.55, help='attention dropout rate')
    parser.add_argument('--num_epochs', default=1000, help='max epochs')
    parser.add_argument('--patience', type=int, default=30, help='patience')
    parser.add_argument('--seed', type=int, default=164, help='random seed')
    parser.add_argument('--device', type=str, default='cuda:0', help='cuda:0 or cpu')
    parser.add_argument('--dropout', type=float, default=0.5, help='dropout rate')
    parser.add_argument('--repeat', type=int, default=1, help='repeat')
    parser.add_argument('--lam', type=float, default=1.0, help='fusion lam')
    parser.add_argument('--alpha', type=float, default=0.5, help='fusion alpha')

    args = parser.parse_args().__dict__
    set_random_seed(args['seed'])
    print(args)
    main(args)
