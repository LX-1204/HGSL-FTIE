import torch
from data import *
from module.yelp.model import HGSL_FTIE
import argparse
import random
from pytorchtools import EarlyStopping
from tools import *
import time
import psutil
import os
import datetime
from sklearn.manifold import TSNE
import matplotlib.pyplot as plt

import warnings
warnings.filterwarnings("ignore")

def set_random_seed(seed=0):
    random.seed(seed)
    np.random.seed(seed)
    torch.manual_seed(seed)
    if torch.cuda.is_available():
        torch.cuda.manual_seed(seed)

def score(logits, labels):
    _, indices = torch.max(logits, dim=1)
    prediction = indices.long().cpu().numpy()
    labels = labels.cpu().numpy()
    accuracy = (prediction == labels).sum() / len(prediction)
    micro_f1 = f1_score(labels, prediction, average='micro')
    macro_f1 = f1_score(labels, prediction, average='macro')
    return accuracy, micro_f1, macro_f1

def main(args):
    features_G, feat, ADJ_t, labels, num_classes, train_idx, val_idx, test_idx =load_YELP_data()
    in_dims = [feature.shape[1] for feature in features_G]
    features_G = [feature.to(args['device']) for feature in features_G]
    labels = labels.to(args['device'])

    for i in range(len(ADJ_t)):
        ADJ_t[i] = ADJ_t[i].to(args['device'])
    for j in range(len(feat)):
        feat[j] = feat[j].to(args['device'])

    svm_macro_avg = np.zeros((7,), dtype=np.float)
    svm_micro_avg = np.zeros((7,), dtype=np.float)
    nmi_avg = 0
    ari_avg = 0
    for cur_repeat in range(args['repeat']):
        model = HGSL_FTIE(args['hidden_units'],args,args['lam'],args['alpha'],in_dims, args['feat_drop'], args['att_drop'] ,len(ADJ_t), num_classes, args['dropout']).to(args['device'])
        early_stopping = EarlyStopping(patience=args['patience'], verbose=True, save_path='checkpoint/checkpoint_{}.pt'.format(args['dataset']))
        loss_fcn = torch.nn.CrossEntropyLoss()
        optimizer = torch.optim.Adam(model.parameters(), lr=args['lr'], weight_decay=args['weight_decay'])
        b = 0
        a = 0
        drop_rate = [0,0]
        for epoch in range(args['num_epochs']):
            b = b + 1
            t = time.time()
            model.train()
            logits, h = model(features_G,feat,ADJ_t,labels,train_idx)
            loss = loss_fcn(logits[train_idx], labels[train_idx])
            optimizer.zero_grad()
            loss.backward()
            optimizer.step()
            t2 = time.time()
            a = a + (t2 - t)
            model.eval()
            logits, h = model(features_G,feat,ADJ_t,labels,train_idx)
            val_loss = loss_fcn(logits[val_idx], labels[val_idx])
            test_loss = loss_fcn(logits[test_idx], labels[test_idx])
            print('Epoch{:d}| Train Loss{:.4f}| Val Loss{:.4f}| Test Loss{:.4f}'.format(epoch + 1, loss.item(), val_loss.item(), test_loss.item()))
            early_stopping(val_loss.data.item(), model)
            if early_stopping.early_stop:
                print('Early stopping!')
                break
        # print('average time:', a / b)
        print('\ntesting...')
        model.load_state_dict(torch.load('checkpoint/checkpoint_{}.pt'.format(args['dataset'])))
        model.eval()
        logits, h = model(features_G,feat,ADJ_t,labels,train_idx)
        accuracy, micro_f1, macro_f1 = score(logits[test_idx], labels[test_idx])
        print('mic=',micro_f1,'  mac=',macro_f1)
        svm_macro, svm_micro, nmi, ari = evaluate_results_nc(h[test_idx].detach().cpu().numpy(), labels[test_idx].cpu().numpy(), int(labels.max()) + 1)
        svm_macro_avg = svm_macro_avg + svm_macro
        svm_micro_avg = svm_micro_avg + svm_micro
        nmi_avg += nmi
        ari_avg += ari

    svm_macro_avg = svm_macro_avg / args['repeat']
    svm_micro_avg = svm_micro_avg / args['repeat']
    nmi_avg /= args['repeat']
    ari_avg /= args['repeat']
    print('---\nThe average of {} results:'.format(args['repeat']))
    print('Macro-F1: ' + ', '.join(['{:.6f}'.format(macro_f1) for macro_f1 in svm_macro_avg]))
    print('Micro-F1: ' + ', '.join(['{:.6f}'.format(micro_f1) for micro_f1 in svm_micro_avg]))
    print('NMI: {:.6f}'.format(nmi_avg))
    print('ARI: {:.6f}'.format(ari_avg))
    print('all finished')


if __name__ == '__main__':
    parser = argparse.ArgumentParser(description='our models')
    parser.add_argument('--dataset', default='YELP', help='dataset')
    parser.add_argument('--lr', default=0.0001, help='learning rate')
    parser.add_argument('--weight_decay', default=0.0000, help='weight decay')
    parser.add_argument('--hidden_units', default=64, help='hidden units')
    parser.add_argument('--feat_drop', default=0.3, help='feature dropout rate')
    parser.add_argument('--att_drop', default=0.6, help='attention dropout rate')
    parser.add_argument('--num_epochs', default=1000, help='max epochs')
    parser.add_argument('--patience', type=int, default=20, help='patience')
    parser.add_argument('--seed', type=int, default=123, help='random seed')
    parser.add_argument('--device', type=str, default='cuda:0', help='cuda:0 or cpu')
    parser.add_argument('--dropout', type=float, default=0.5, help='dropout rate')
    parser.add_argument('--repeat', type=int, default=1, help='repeat')
    parser.add_argument('--lam', type=float, default=0.2, help='fusion lam')
    parser.add_argument('--alpha', type=float, default=1.0, help='fusion alpha')

    args = parser.parse_args().__dict__
    set_random_seed(args['seed'])
    print(args)
    main(args)