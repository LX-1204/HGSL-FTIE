import numpy as np
import scipy
import pickle
import torch
import dgl
import torch.nn.functional as F
import torch as th
import scipy.sparse as sp
from util_funcs import cos_sim
# import tensorflow as tf
from sklearn.metrics.pairwise import cosine_similarity as cos

def load_ACM_data(prefix=r'D:\Anaconda\Pycharm\Code\xin_2\HGSLFTIE\DATASET\ACM'):
    features_0 = scipy.sparse.load_npz(prefix + '/features_0.npz').toarray()
    features_1 = scipy.sparse.load_npz(prefix + '/features_1.npz').toarray()
    features_2 = scipy.sparse.load_npz(prefix + '/features_2.npz').toarray()

    features_0 = torch.FloatTensor(features_0)
    features_1 = torch.FloatTensor(features_1)
    features_2 = torch.FloatTensor(features_2)
    feat = [features_0, features_1, features_2]

    ADJ = scipy.sparse.load_npz(prefix + '/adjM.npz').A
    ADJ = torch.FloatTensor(ADJ)


    pa = ADJ[:4019, 4019:4019 + 7167]

    pa = F.normalize(pa, dim=1, p=2)
    feat_pa = torch.mm(pa, features_1)
    feat_pa = F.normalize(feat_pa, dim=1, p=2)

    ps = ADJ[:4019, 4019 + 7167:]
    ps = F.normalize(ps, dim=1, p=2)
    feat_ps = torch.mm(ps, features_2)
    feat_ps = F.normalize(feat_ps, dim=1, p=2)

    pp = ADJ[:4019, :4019]
    pp = F.normalize(pp, dim=1, p=2)
    feat_pp = torch.mm(pp, features_0)
    feat_pp = F.normalize(feat_pp, dim=1, p=2)

    pap = scipy.sparse.load_npz(prefix + '/pap.npz').A
    pap = torch.from_numpy(pap).type(torch.FloatTensor)
    pap = F.normalize(pap, dim=1, p=2)
    feat_pap = torch.mm(pap, features_0)
    feat_pap = F.normalize(feat_pap, dim=1, p=2)

    psp = scipy.sparse.load_npz(prefix + '/psp.npz').A
    psp = torch.from_numpy(psp).type(torch.FloatTensor)
    psp = F.normalize(psp, dim=1, p=2)
    feat_psp = torch.mm(psp, features_0)
    feat_psp = F.normalize(feat_psp, dim=1, p=2)

    feat_ppap = torch.mm(pp, feat_pap)
    feat_ppap = F.normalize(feat_ppap, dim=1, p=2)
    feat_ppsp = torch.mm(pp, feat_psp)
    feat_ppsp = F.normalize(feat_ppsp, dim=1, p=2)

    ADJ_t = [pap, psp]
    features_0 = F.normalize(features_0, dim=1, p=2)
    features_G = [features_0, feat_pp, feat_pa, feat_ps, feat_pap, feat_psp,feat_ppap,feat_ppsp]
    labels = np.load(prefix + '/labels.npy')
    labels = torch.LongTensor(labels)
    train_val_test_idx = np.load(prefix + '/train_val_test_idx.npz')
    train_idx = train_val_test_idx['train_idx']
    val_idx = train_val_test_idx['val_idx']
    test_idx = train_val_test_idx['test_idx']
    num_classes = 3

    return features_G, feat, ADJ_t, labels, num_classes, train_idx, val_idx, test_idx


def load_DBLP_data(prefix=r'D:\Anaconda\Pycharm\Code\xin_2\HGSLFTIE\DATASET\DBLP'):
    features_0 = scipy.sparse.load_npz(prefix + '/features_0.npz').toarray()
    features_1 = scipy.sparse.load_npz(prefix + '/features_1.npz').toarray()
    features_2 = np.load(prefix + '/features_2.npy')
    features_3 = np.eye(20)

    features_0 = torch.FloatTensor(features_0)
    features_1 = torch.FloatTensor(features_1)
    features_2 = torch.FloatTensor(features_2)
    features_3 = torch.FloatTensor(features_3)
    feat = [features_0, features_1, features_2,features_3]

    adjM = scipy.sparse.load_npz(prefix + '/adjM.npz').A
    adjM = torch.FloatTensor(adjM)

    ap=adjM[0:4057,4057:4057+14328]
    pt=adjM[4057:4057+14328,4057+14328:4057+14328+7723]
    pc=adjM[4057:4057+14328,4057+14328+7723:]
    at=torch.mm(ap,pt)
    ac=torch.mm(ap,pc)

    ap = F.normalize(ap, dim=1, p=2)
    feat_ap=torch.mm(ap,features_1)
    feat_ap=F.normalize(feat_ap, dim=1, p=2)

    at = F.normalize(at, dim=1, p=2)
    feat_at=torch.mm(at,features_2)
    feat_at=F.normalize(feat_at, dim=1, p=2)

    ac = F.normalize(ac, dim=1, p=2)
    feat_ac=torch.mm(ac,features_3)
    feat_ac=F.normalize(feat_ac, dim=1, p=2)

    apa = scipy.sparse.load_npz(prefix + '/apa.npz').A
    apa = torch.from_numpy(apa).type(torch.FloatTensor)
    apa = F.normalize(apa, dim=1, p=2)
    feat_apa=torch.mm(apa,features_0)
    feat_apa=F.normalize(feat_apa, dim=1, p=2)

    aptpa = scipy.sparse.load_npz(prefix + '/aptpa.npz').A
    aptpa = torch.from_numpy(aptpa).type(torch.FloatTensor)
    aptpa = F.normalize(aptpa, dim=1, p=2)
    feat_aptpa=torch.mm(aptpa,features_0)
    feat_aptpa=F.normalize(feat_aptpa, dim=1, p=2)


    apcpa = scipy.sparse.load_npz(prefix + '/apcpa.npz').A
    apcpa = torch.from_numpy(apcpa).type(torch.FloatTensor)
    apcpa = F.normalize(apcpa, dim=1, p=2)
    feat_apcpa=torch.mm(apcpa,features_0)
    feat_apcpa=F.normalize(feat_apcpa, dim=1, p=2)
    ADJ_t = [apa,aptpa,apcpa]

    features_0 = F.normalize(features_0, dim=1, p=2)
    features_G = [features_0, feat_ap, feat_at, feat_ac, feat_apa, feat_aptpa, feat_apcpa]
    labels = np.load(prefix + '/labels.npy')
    labels = torch.LongTensor(labels)
    train_val_test_idx = np.load(prefix + '/train_val_test_idx.npz')
    train_idx = train_val_test_idx['train_idx']
    val_idx = train_val_test_idx['val_idx']
    test_idx = train_val_test_idx['test_idx']
    num_classes = 4

    return features_G, feat, ADJ_t, labels, num_classes,train_idx, val_idx, test_idx


def load_YELP_data(prefix=r'D:\Anaconda\Pycharm\Code\xin_2\HGSLFTIE\DATASET\YELP'):
    features_0 = scipy.sparse.load_npz(prefix + '/features_0_b.npz').toarray()
    features_1 = scipy.sparse.load_npz(prefix + '/features_1_u.npz').toarray()
    features_2 = scipy.sparse.load_npz(prefix + '/features_2_s.npz').toarray()
    features_3 = scipy.sparse.load_npz(prefix + '/features_3_l.npz').toarray()
    features_0 = torch.FloatTensor(features_0)
    features_1 = torch.FloatTensor(features_1)
    features_2 = torch.FloatTensor(features_2)
    features_3 = torch.FloatTensor(features_3)

    feat = [features_0, features_1, features_2,features_3]
    ADJ = scipy.sparse.load_npz(prefix + '/adjM.npz').A
    ADJ = torch.FloatTensor(ADJ)

    bu=ADJ[0:2614,2614:2614+1286]
    bs=ADJ[0:2614,2614+1286:2614+1286+4]
    bl=ADJ[0:2614,2614+1286+4:]

    bu = F.normalize(bu, dim=1, p=2)
    feat_bu=torch.mm(bu,features_1)
    feat_bu=F.normalize(feat_bu, dim=1, p=2)

    bs = F.normalize(bs, dim=1, p=2)
    feat_bs=torch.mm(bs,features_2)
    feat_bs=F.normalize(feat_bs, dim=1, p=2)

    bl = F.normalize(bl, dim=1, p=2)
    feat_bl=torch.mm(bl,features_3)
    feat_bl=F.normalize(feat_bl, dim=1, p=2)

    bub = scipy.sparse.load_npz(prefix + '/adj_bub.npz').A
    bub= torch.from_numpy(bub).type(torch.FloatTensor)
    bub = F.normalize(bub, dim=1, p=2)
    feat_bub=torch.mm(bub,features_0)
    feat_bub=F.normalize(feat_bub, dim=1, p=2)

    bsb = scipy.sparse.load_npz(prefix + '/adj_bsb.npz').A
    bsb= torch.from_numpy(bsb).type(torch.FloatTensor)
    bsb = F.normalize(bsb, dim=1, p=2)
    feat_bsb=torch.mm(bsb,features_0)
    feat_bsb=F.normalize(feat_bsb, dim=1, p=2)

    blb = scipy.sparse.load_npz(prefix + '/adj_blb.npz').A
    blb= torch.from_numpy(blb).type(torch.FloatTensor)
    blb = F.normalize(blb, dim=1, p=2)
    feat_blb=torch.mm(blb,features_0)
    feat_blb=F.normalize(feat_blb, dim=1, p=2)

    ADJ_t = [bub, bsb, blb]
    bubs = torch.mm(torch.mm(bu,bu.t()),bs)
    bubs = F.normalize(bubs, dim=1, p=2)
    feat_bubs=torch.mm(bubs,features_2)
    feat_bubs=F.normalize(feat_bubs, dim=1, p=2)

    bubl = torch.mm(torch.mm(bu,bu.t()),bl)
    bubl = F.normalize(bubl, dim=1, p=2)
    feat_bubl=torch.mm(bubl,features_3)
    feat_bubl=F.normalize(feat_bubl, dim=1, p=2)

    bsbu = torch.mm(torch.mm(bs,bs.t()),bu)
    bsbu = F.normalize(bsbu, dim=1, p=2)
    feat_bsbu=torch.mm(bsbu,features_1)
    feat_bsbu=F.normalize(feat_bsbu, dim=1, p=2)

    bsbl = torch.mm(torch.mm(bs,bs.t()),bl)
    bsbl = F.normalize(bsbl, dim=1, p=2)
    feat_bsbl=torch.mm(bsbl,features_3)
    feat_bsbl=F.normalize(feat_bsbl, dim=1, p=2)

    blbu = torch.mm(torch.mm(bl,bl.t()),bu)
    blbu = F.normalize(blbu, dim=1, p=2)
    feat_blbu=torch.mm(blbu,features_1)
    feat_blbu=F.normalize(feat_blbu, dim=1, p=2)

    blbs = torch.mm(torch.mm(bl,bl.t()),bs)
    blbs = F.normalize(blbs, dim=1, p=2)
    feat_blbs=torch.mm(blbs,features_2)
    feat_blbs=F.normalize(feat_blbs, dim=1, p=2)

    features_0 = F.normalize(features_0, dim=1, p=2)
    # features = [features_0, feat_bu, feat_bs, feat_bl,feat_bub,feat_bsb,feat_blb]#,feat_bubs,feat_bubl,feat_bsbu,feat_bsbl,feat_blbu,feat_blbs]
    features_G = [features_0,feat_bu, feat_bs, feat_bl,feat_bub,feat_bsb,feat_blb]
    labels = np.load(prefix + '/labels.npy')
    labels = torch.LongTensor(labels)
    train_val_test_idx = np.load(prefix + '/train_val_test_idx.npy',allow_pickle=True)
    train_val_test_idx = train_val_test_idx.item()
    train_idx = train_val_test_idx['train_idx']
    val_idx = train_val_test_idx['val_idx']
    test_idx = train_val_test_idx['test_idx']
    num_classes = 3

    return features_G, feat, ADJ_t, labels, num_classes,train_idx, val_idx, test_idx
