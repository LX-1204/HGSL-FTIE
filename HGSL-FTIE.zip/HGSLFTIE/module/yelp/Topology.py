import torch.nn as nn
import torch
import torch.nn.functional as F
from torch.nn.parameter import Parameter
import math
class topology_encoder(nn.Module):
    def __init__(self, hidden_dim, dropout, attn_drop, mp_num):
        super(topology_encoder, self).__init__()
        self.hidden_dim = hidden_dim
        self.encoder = nn.ModuleList([GraphConvolution(hidden_dim, hidden_dim, dropout) for i in range(mp_num)])
        self.decoder = nn.ModuleList([InnerProductDecoder(dropout, act=lambda x: x) for i in range(mp_num)])
        self.sema_att = Inter_att(2614, attn_drop)
        self.predict = nn.Linear(hidden_dim, hidden_dim, bias=True)

    def forward(self,  ADJ_t):
        adj_t = self.sema_att(ADJ_t)
        adj_t = F.normalize(adj_t, dim=1, p=1)
        return adj_t

class InnerProductDecoder(nn.Module):
    def __init__(self, dropout, act=torch.sigmoid):
        super(InnerProductDecoder, self).__init__()
        self.dropout = dropout
        self.act = act

    def forward(self, z):
        z = F.dropout(z, self.dropout, training=self.training)
        adj = self.act(torch.mm(z, z.t()))
        return adj

class Inter_att(nn.Module):
    def __init__(self, hidden_dim, attn_drop):
        super(Inter_att, self).__init__()
        self.fc = nn.Linear(hidden_dim, hidden_dim, bias=True)
        nn.init.xavier_normal_(self.fc.weight, gain=1.414)

        self.tanh = nn.Tanh()
        self.att = nn.Parameter(torch.empty(size=(1, hidden_dim)), requires_grad=True)
        nn.init.xavier_normal_(self.att.data, gain=1.414)

        self.softmax = nn.Softmax(dim=0)
        if attn_drop:
            self.attn_drop = nn.Dropout(attn_drop)
        else:
            self.attn_drop = lambda x: x

    def forward(self, embeds):
        beta = []
        attn_curr = self.attn_drop(self.att)
        for embed in embeds:
            sp = self.tanh(self.fc(embed)).mean(dim=0)
            beta.append(attn_curr.matmul(sp.t()))
        beta = torch.cat(beta, dim=-1).view(-1)
        beta = self.softmax(beta)
        z_mc = 0
        for i in range(len(embeds)):
            z_mc += embeds[i] * beta[i]
        return z_mc

class GraphConvolution(nn.Module):
    def __init__(self, in_features, out_features, dropout=0, bias=True):
        super(GraphConvolution, self).__init__()
        self.in_features = in_features
        self.out_features = out_features
        self.dropout = dropout
        self.weight = Parameter(torch.FloatTensor(in_features, out_features))
        if bias:
            self.bias = Parameter(torch.FloatTensor(out_features))
        else:
            self.register_parameter('bias', None)
        self.reset_parameters()

    def reset_parameters(self):
        stdv = 1. / math.sqrt(self.weight.size(1))
        self.weight.data.uniform_(-stdv, stdv)
        if self.bias is not None:
            self.bias.data.uniform_(-stdv, stdv)

    def forward(self, inputs, adj):
        inputs = F.dropout(inputs, self.dropout, self.training)
        support = torch.spmm(inputs, self.weight)
        output = torch.spmm(adj, support)
        if self.bias is not None:
            return output + self.bias
        else:
            return output