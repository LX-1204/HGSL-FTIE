import torch
import torch.nn as nn
import torch.nn.functional as F
import numpy as np
import torch as th
import math
from torch.nn.parameter import Parameter
from torch.nn.modules.module import Module
from HGSLFTIE.data import *
from .Feature import Feature_encoder
from .Topology import topology_encoder
from .fusion import Fusion_G


class HGSL_FTIE(nn.Module):
    def __init__(self, hidden_dim,args,lam,alpha,feats_dim_list, dropout, attn_drop, mp_num,num_classes,feat_drop):
        super(HGSL_FTIE, self).__init__()
        self.hidden_dim = hidden_dim
        self.fc_list = nn.ModuleList([nn.Linear(feats_dim, hidden_dim, bias=True) for feats_dim in feats_dim_list])
        self.args = args

        for fc in self.fc_list:
            nn.init.xavier_normal_(fc.weight, gain=1.414)
        if dropout > 0:
            self.feat_drop = nn.Dropout(dropout)
        else:
            self.feat_drop = lambda x: x

        self.feat = Feature_encoder(hidden_dim, feats_dim_list, feat_drop, num_classes)
        self.topo = topology_encoder(hidden_dim, dropout, attn_drop, mp_num)
        self.cls = GCN_two(hidden_dim, hidden_dim, hidden_dim, dropout)
        self.gcn = GCN_two(hidden_dim, hidden_dim, hidden_dim, dropout)
        self.fusion = Fusion_G(lam, alpha)


    def forward(self,features_G,feat,ADJ_t,labels,train_idx):
        feat1 = []
        for i in range(len(feat)):
            feat1.append(F.elu(self.feat_drop(self.fc_list[i](feat[i]))))
        feat1= feat1[0]
        adj_f = self.feat(features_G)
        adj_t=self.topo(ADJ_t)
        prob_v1 = self.cls(feat1, adj_f)
        prob_v2 = self.cls(feat1, adj_t)
        prob_v1 = F.softmax(prob_v1)
        prob_v2= F.softmax(prob_v2)
        logits_v1 =torch.log(prob_v1 + 1e-8)
        logits_v2 = torch.log(prob_v2 + 1e-8)

        S = self.fusion(adj_f, prob_v1, adj_t, prob_v2)
        h = self.gcn(feat1, S)

        logits = F.softmax(h + 1e-8)
        logits  = - torch.log(logits + 1e-8)

        return logits,h

def sparse_mx_to_torch_sparse_tensor(sparse_mx):
    """Convert a scipy sparse matrix to a torch sparse tensor."""
    sparse_mx = sparse_mx.tocoo().astype(np.float32)
    indices = th.from_numpy(
        np.vstack((sparse_mx.row, sparse_mx.col)).astype(np.int64))
    values = th.from_numpy(sparse_mx.data)
    shape = th.Size(sparse_mx.shape)
    return th.sparse.FloatTensor(indices, values, shape)

class GCN(nn.Module):
    def __init__(self, nfeat, nhid, out, dropout):
        super(GCN, self).__init__()
        self.gc1 = GraphConvolution(nfeat, nhid)
        self.gc2 = GraphConvolution(nhid, 3)
        self.dropout = dropout

    def forward(self, x, adj):
        x = F.relu(self.gc1(x, adj))
        x = F.dropout(x, self.dropout, training = self.training)
        x = self.gc2(x, adj)
        return x

class GCN1(nn.Module):
    def __init__(self, nfeat, nhid, out, dropout):
        super(GCN1, self).__init__()
        self.gc1 = GraphConvolution(nfeat, nhid)
        self.gc2 = GraphConvolution(nhid, 64)
        self.dropout = dropout

    def forward(self, x, adj):
        x = F.relu(self.gc1(x, adj))
        x = F.dropout(x, self.dropout, training = self.training)
        x = self.gc2(x, adj)
        return x

class GCN_two(nn.Module):
    def __init__(self, input_dim, hid_dim1, hid_dim2, dropout, activation="relu"):
        super(GCN_two, self).__init__()
        self.conv1 = GCN_one(input_dim, hid_dim1)
        self.conv2 = GCN_one(hid_dim1, 3)

        self.dropout = dropout
        assert activation in ["relu", "leaky_relu", "elu"]
        self.activation = getattr(F, activation)

    def forward(self, feature, adj):
        x1 = self.activation(self.conv1(feature, adj))
        x1 = F.dropout(x1, p=self.dropout, training=self.training)
        x2 = self.conv2(x1, adj)
        return x2  # F.log_softmax(x2, dim=1)

class GCN_one(nn.Module):
    def __init__(self, in_ft, out_ft, bias=True, activation=None):
        super(GCN_one, self).__init__()
        self.fc = nn.Linear(in_ft, out_ft, bias=False)
        self.activation = activation
        if bias:
            self.bias = nn.Parameter(torch.FloatTensor(out_ft))
            self.bias.data.fill_(0.0)
        else:
            self.register_parameter('bias', None)

        for m in self.modules():
            self.weights_init(m)

    def weights_init(self, m):
        if isinstance(m, nn.Linear):
            torch.nn.init.xavier_uniform_(m.weight.data)
            if m.bias is not None:
                m.bias.data.fill_(0.0)

    def forward(self, feat, adj):
        adj = adj.to_dense()
        feat = self.fc(feat)
        out = torch.spmm(adj, feat)
        if self.bias is not None:
            out += self.bias
        if self.activation is not None:
            out = self.activation(out)
        return out

class GraphConvolution(Module):
    """
    Simple GCN layer, similar to https://arxiv.org/abs/1609.02907
    """

    def __init__(self, in_features, out_features, bias=True):
        super(GraphConvolution, self).__init__()
        self.in_features = in_features
        self.out_features = out_features
        self.weight = Parameter(torch.FloatTensor(in_features, out_features))
        if bias:
            self.bias = Parameter(torch.FloatTensor(out_features))
        else:
            self.register_parameter('bias', None)
        self.reset_parameters()

    def reset_parameters(self):
        stdv = 1. / math.sqrt(self.weight.size(1))
        self.weight.data.uniform_(-stdv, stdv)
        if self.bias is not None:
            self.bias.data.uniform_(-stdv, stdv)

    def forward(self, input, adj):
        support = torch.mm(input, self.weight)
        output = torch.spmm(adj, support)
        if self.bias is not None:
            return output + self.bias
        else:
            return output

    def __repr__(self):
        return self.__class__.__name__ + ' (' \
               + str(self.in_features) + ' -> ' \
               + str(self.out_features) + ')'

class Inter_att(nn.Module):
    def __init__(self, hidden_dim, attn_drop):
        super(Inter_att, self).__init__()
        self.fc = nn.Linear(hidden_dim, hidden_dim, bias=True)
        nn.init.xavier_normal_(self.fc.weight, gain=1.414)

        self.tanh = nn.Tanh()
        self.att = nn.Parameter(torch.empty(size=(1, hidden_dim)), requires_grad=True)
        nn.init.xavier_normal_(self.att.data, gain=1.414)

        self.softmax = nn.Softmax(dim=0)
        if attn_drop:
            self.attn_drop = nn.Dropout(attn_drop)
        else:
            self.attn_drop = lambda x: x

    def forward(self, embeds):
        beta = []
        attn_curr = self.attn_drop(self.att)
        for embed in embeds:
            sp = self.tanh(self.fc(embed)).mean(dim=0)
            beta.append(attn_curr.matmul(sp.t()))
        beta = torch.cat(beta, dim=-1).view(-1)
        beta = self.softmax(beta)
        z_mc = 0
        for i in range(len(embeds)):
            z_mc += embeds[i] * beta[i]
        return z_mc

