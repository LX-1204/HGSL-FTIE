import torch
import torch.nn as nn
import torch.nn.functional as F

class Feature_encoder(nn.Module):
    def __init__(self,  hidden_dim, feats_dim_list, feat_drop, num_classes):
        super(Feature_encoder, self).__init__()
        self.hidden_dim = hidden_dim
        self.fc_v = nn.Linear(320, 4057, bias=True)
        nn.init.xavier_normal_(self.fc_v.weight, gain=1.414)
        self.fc_v2 = nn.Linear(4057, hidden_dim, bias=True)
        nn.init.xavier_normal_(self.fc_v2.weight, gain=1.414)

        self.fc_list = nn.ModuleList([nn.Linear(feats_dim, hidden_dim, bias=True)
                                      for feats_dim in feats_dim_list])
        for fc in self.fc_list:
            nn.init.xavier_normal_(fc.weight, gain=1.414)

        if feat_drop > 0:
            self.feat_drop = nn.Dropout(feat_drop)
        else:
            self.feat_drop = lambda x: x

        self.predict_1 = nn.Linear(hidden_dim, hidden_dim, bias=True)
        self.predict_2 = nn.Linear(hidden_dim, num_classes, bias=True)
        self.feat_trans = nn.Linear(hidden_dim * len(feats_dim_list),hidden_dim, bias=True)

    def forward(self, features_G):
        h_all = []
        for i in range(len(features_G)):
            h_all.append(F.elu(self.fc_list[i](features_G[i])))
        h = torch.cat((h_all[0], h_all[1], h_all[2], h_all[3], h_all[4]), 1)
        adj_f = self.fc_v(h)
        return adj_f

